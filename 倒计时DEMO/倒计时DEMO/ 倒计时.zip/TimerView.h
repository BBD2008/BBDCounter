//
//  TimerView.h
//  倒计时DEMO
//
//  Created by heima on 16/5/26.
//  Copyright © 2016年 lxc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimerView : UIButton

// 构造方法
- (instancetype)initWithFrame:(CGRect)frame lineWidth:(int)lineWidth lineColor:(UIColor *)color font:(UIFont *)font;

@end
