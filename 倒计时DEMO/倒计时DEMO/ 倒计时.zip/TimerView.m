//
//  TimerView.m
//  倒计时DEMO
//
//  Created by heima on 16/5/26.
//  Copyright © 2016年 lxc. All rights reserved.
//

#import "TimerView.h"

@interface TimerView ()

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, assign) float time;

@property (nonatomic, assign) CGPoint timerCenter;

@property (nonatomic, assign) UIFont *timerFont;

@property (nonatomic, assign) CGFloat timerRadius;

@property (nonatomic, assign) CGFloat timerLineWidth;

@property (nonatomic, strong) UIColor *timerLineColor;

@end

@implementation TimerView

- (instancetype)initWithFrame:(CGRect)frame lineWidth:(int)lineWidth lineColor:(UIColor *)color font:(UIFont *)font
{
    self = [super initWithFrame:frame];
    
    if (self)
    {
        // 设置圆心
        self.timerCenter = CGPointMake(frame.size.width / 2, frame.size.height /2);
        
        // 设置半径
        self.timerRadius = MIN(self.timerCenter.x, self.timerCenter.y) - self.timerLineWidth;
        
        // 设置线宽
        self.timerLineWidth = lineWidth;
        
        // 设置文字大小
        [self.titleLabel setFont:font];
        
        // 设置颜色
        self.timerLineColor = color;
        
        [self setTitleColor:self.timerLineColor forState:UIControlStateNormal];
        
        self.backgroundColor = [UIColor clearColor];
        
        // 设置文字
        [self setTitle:@"60" forState:UIControlStateNormal];
        
        self.time = 59.0;
        
        // 启动定时器
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(refresh) userInfo:@"倒计时工具" repeats:YES];
    }
    
    return self;
}



- (void)refresh
{
    // 刷新文字
    [self setTitle:[NSString stringWithFormat:@"%.0f", self.time] forState:UIControlStateNormal];
    
    // 调用drawRect方法
    [self setNeedsDisplay];
    
    // 调整文字
    if (self.time > 0)
    {
        self.time --;
    }
    else if (self.time == 0)
    {
        [self setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    }
}

- (void)drawRect:(CGRect)rect
{
    [self drawGrayPath];
    
    [self drawColorPath];
}

- (void)drawColorPath
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    CGFloat startAngle = - M_PI_2;
    
    CGFloat endAngle = 2 * M_PI * (self.time / 60) + startAngle;
    
    [path addArcWithCenter:self.timerCenter radius:self.timerRadius - self.timerLineWidth startAngle:startAngle endAngle:endAngle clockwise:YES];
    
    path.lineWidth = self.timerLineWidth;
    
    path.lineCapStyle = kCGLineCapRound;
    
    [self.timerLineColor setStroke];
    
    [path stroke];
}

- (void)drawGrayPath
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    CGFloat startAngle = 0;
    
    CGFloat endAngle = 2 * M_PI;
    
    [path addArcWithCenter:self.timerCenter radius:self.timerRadius - self.timerLineWidth startAngle:startAngle endAngle:endAngle clockwise:NO];
    
    path.lineWidth = self.timerLineWidth;
    
    path.lineCapStyle = kCGLineCapRound;
    
    [[UIColor lightGrayColor] setStroke];
    
    [path stroke];
}

@end
